import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/components/root/app.module';

platformBrowserDynamic().bootstrapModule(AppModule);
