import {Component} from '@angular/core';

@Component({
    selector: 'edit',
    templateUrl: 'app/components//edit/edit.component.html',
    styleUrls: ['app/components/edit/edit.component.css'],
})

export class EditComponent {

}
