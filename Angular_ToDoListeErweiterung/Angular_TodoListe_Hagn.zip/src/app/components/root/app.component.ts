import {Component} from '@angular/core';

@Component({
    selector: 'app',
    template: `<router-outlet></router-outlet>`,
    styleUrls: ['app/components/root/app.component.css']
})

export class AppComponent {
}
